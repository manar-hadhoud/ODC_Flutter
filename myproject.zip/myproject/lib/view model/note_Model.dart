class NoteModel {
  int? id;
  String? tittle;
  String? body;
  DateTime? creationDate;

  NoteModel({this.id,this.tittle,this.body,this.creationDate});

  Map<String, dynamic> toMap() {
    return ({
      "id": id,
      "tittle": tittle,
      "body": body,
      "creationDate": creationDate.toString(),
    });
  }
}