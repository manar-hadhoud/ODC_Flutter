
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

import '../note_Model.dart';

class DatabaseProvider {
  DatabaseProvider._();
  static final DatabaseProvider dp = DatabaseProvider._();
  static Database? _database;

  Future<Database> get database async {

    if(_database != null) {
      return database!;
    }

    _database = await initDB();
    return _database!;
  }

  initDB() async {
    return await openDatabase(join(await getDatabasesPath(), "note.dp"),
        onCreate: (dp, version) async {
          await dp.execute('''
      CREATE TABLE notes (
      id INTEGER PRIMARY KEY AUTOINREMENT,
      title Text,
      body Text,
      creation_date DATE
      )
      ''');
        }, version: 1);
  }

  addNewNote(NoteModel note) async {
    final dp = await database;
    dp.insert("notes", note.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<dynamic> getNotes() async {
    final dp = await database;
    var res = await dp.query("notes");
    if(res.length == 0){
      return null;
    } else{
      var resultMap = res.toList();
      return resultMap.isNotEmpty? resultMap : null;
    }
  }
}