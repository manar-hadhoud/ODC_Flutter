part of '../../pages/signup/signupCubit.dart';

abstract class signupState {}

class signup_Initial extends signupState {}

class success extends signupState{}

class failure extends signupState{}
