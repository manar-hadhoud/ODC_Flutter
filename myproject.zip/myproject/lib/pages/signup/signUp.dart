import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:myproject/pages/signup/signupCubit.dart';


import '../../components/formComponent.dart';

class signUp extends StatefulWidget {
  @override
  State<signUp> createState() => _signUpState();
}

class _signUpState extends State<signUp> {
  String? genderVal;
  String? value;
  String? UniVal;
  String? gradVal;
  List _Gender = ['Female', 'Male'];
  List _University = ['ASU', 'AUC', 'Cairo', 'ELU', 'GUC','Helwan','HTI'];
  List _Grade = ['Grade 1', 'Grade 2', 'Grade 3', 'Grade 4','Grade 5'];
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
        create: (context) => signupCubit(),
        child: BlocConsumer<signupCubit, signupState>(
            listener: (context, state) {},
            builder: (context, state) {
              signupCubit myCubit = signupCubit.get(context);
              return MaterialApp(
                  debugShowCheckedModeBanner: false,
                  home: Scaffold(
                body: SingleChildScrollView(
                  child: Column(children: [
                    SizedBox(
                      height: 70,
                    ),
                    Center(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            height: 80,
                          ),
                          Text("Orange ",
                              style: GoogleFonts.poppins(
                                  fontSize: 25,
                                  fontWeight: FontWeight.bold,
                                  textStyle: TextStyle(
                                      color: Colors.deepOrange,
                                      letterSpacing: .5))),
                          Text("Digital Center",
                              style: GoogleFonts.poppins(
                                  fontSize: 25, fontWeight: FontWeight.bold))
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 50,
                    ),
                    ListTile(
                      title: Text("Sign Up",
                          style: GoogleFonts.poppins(
                              fontSize: 25, fontWeight: FontWeight.w500)),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    sign_Form('Name', myCubit.name),
                    SizedBox(
                      height: 20,
                    ),
                    sign_Form('E-Mail', myCubit.emailct),
                    SizedBox(
                      height: 20,
                    ),
                    SizedBox(
                        width: 350,
                        height: 45,
                        child: TextField(
                          obscureText: true,
                          controller: myCubit.passwordct,
                          decoration: InputDecoration(
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(13),
                              ),
                              focusedBorder: const OutlineInputBorder(
                                 borderRadius: BorderRadius.all(Radius.circular(5)),
                                  borderSide: BorderSide(color: Colors.deepOrangeAccent)),
                              hintText: 'Password',
                              labelText: 'Password',
                              suffixIcon: Icon(
                                Icons.remove_red_eye,
                                color: Colors.deepOrange,
                              )),

                        )),
                    SizedBox(
                      height: 20,
                    ),
                    SizedBox(
                        width: 350,
                        height: 45,
                        child: TextField(
                            obscureText: true,
                            controller: myCubit.passwordct0,
                          decoration: InputDecoration(
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(13),
                              ),
                              focusedBorder: const OutlineInputBorder(
                                  borderRadius: BorderRadius.all(Radius.circular(5)),
                                  borderSide: BorderSide(color: Colors.deepOrangeAccent)),
                              hintText: 'Password',
                              labelText: 'Password',
                              suffixIcon: const Icon(
                                Icons.remove_red_eye,
                                color: Colors.deepOrange,
                              )),
                        )),
                    SizedBox(
                      height: 20,
                    ),
                    sign_Form('Phone Number', myCubit.phoneNum),
                    SizedBox(
                      height: 20,
                    ),
                    Row(
                      children: [
                        SizedBox(width: 60),
                        Expanded(
                          child: ListTile(
                              title: Text("Gender",
                                  style: GoogleFonts.poppins(
                                      fontSize: 15,
                                      fontWeight: FontWeight.w300,
                                      color: Colors.black))),
                        ),
                        Expanded(
                            child: ListTile(
                          title: Text("University",
                              style: GoogleFonts.poppins(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w300,
                                  color: Colors.black)),
                        ))
                      ],
                    ),
                    SizedBox(height: 0),
                    Row(
                      children: [
                        SizedBox(width: 58),
                        Container(
                          width: 80,
                          //margin: EdgeInsets.fromLTRB(100, 20, 199, 20),
                          padding:
                              const EdgeInsets.only(left: 00.0, right: 00.0),
                          decoration: BoxDecoration(
                              border: Border.all(
                                  color: Colors.deepOrange, width: 1.0),
                              borderRadius: BorderRadius.circular(15)),
                          child: DropdownButton(
                            hint: Text("Female",
                                style: TextStyle(
                                    fontSize: 15, color: Colors.black)),
                            dropdownColor: Colors.white,
                            elevation: 5,
                            icon: Icon(Icons.arrow_drop_down),
                            iconSize: 26.0,
                            isExpanded: true,
                            value: genderVal,
                            onChanged: (value) {
                              setState(() {
                                genderVal = value! as String?;
                              });
                            },
                            items: _Gender.map((value) {
                              return DropdownMenuItem(
                                value: value,
                                child: Text(value),
                              );
                            }).toList(),
                          ),
                        ),
                        SizedBox(width: 100),
                        Container(
                          width: 74,
                          padding:
                              const EdgeInsets.only(left: 00.0, right: 00.0),
                          decoration: BoxDecoration(
                              border: Border.all(
                                  color: Colors.deepOrangeAccent, width: 1.0),
                              borderRadius: BorderRadius.circular(15)),
                          child: DropdownButton(
                            hint: Text("ASU",
                                style: TextStyle(
                                    fontSize: 15, color: Colors.black)),
                            dropdownColor: Colors.white,
                            elevation: 5,
                            icon: Icon(Icons.arrow_drop_down),
                            iconSize: 30.0,
                            isExpanded: true,
                            value: UniVal,
                            onChanged: (_value) {
                              setState(() {
                                UniVal = _value! as String?;
                              });
                            },
                            items: _University.map((value) {
                              return DropdownMenuItem(
                                value: value,
                                child: Text(value),
                              );
                            }).toList(),
                          ),
                        ),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Column(
                          children: [
                            Text("Grade",
                                style: GoogleFonts.poppins(
                                    fontSize: 15, fontWeight: FontWeight.w300)),
                            SizedBox(
                              height: 10,
                            ),
                            Container(
                              width: 85,
                              decoration: BoxDecoration(
                                  border: Border.all(
                                      color: Colors.deepOrangeAccent,
                                      width: 1.0),
                                  borderRadius: BorderRadius.circular(15)),
                              child: DropdownButton(
                                hint: Text("Grade1",
                                    style: TextStyle(
                                        fontSize: 15, color: Colors.black)),
                                dropdownColor: Colors.white,
                                elevation: 5,
                                icon: Icon(Icons.arrow_drop_down),
                                iconSize: 30.0,
                                isExpanded: true,
                                value: gradVal,
                                onChanged: (value) {
                                  setState(() {
                                    gradVal = value! as String?;
                                  });
                                },
                                items: _Grade.map((value) {
                                  return DropdownMenuItem(
                                    value: value,
                                    child: Text(value),
                                  );
                                }).toList(),
                              ),
                            ),
                          ],
                        )
                      ],
                    ),
                    SizedBox(height: 30),
                    SizedBox(
                      height: 30,
                    ),
                    SizedBox(
                      width: 350,
                      height: 45,
                      child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.deepOrange,
                              side: BorderSide(
                                width: 2,
                                color: Colors.deepOrange,
                              ),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10))),
                          child: Text("Sign Up",
                              style: GoogleFonts.poppins(
                                  fontSize: 25,
                                  fontWeight: FontWeight.bold,
                                  textStyle: TextStyle(
                                      color: Colors.white, letterSpacing: .5))),
                          onPressed: () {
                            myCubit.registerUser(context);
                          }),
                    ), //signup
                    SizedBox(
                      height: 25,
                    ),
                    Row(
                      children: const [
                        Expanded(
                          child: Divider(
                              color: Colors.black54,
                              thickness: .5,
                              indent: 10,
                              endIndent: 10),
                        ),
                        Text(
                          "OR",
                          style: TextStyle(
                              fontSize: 20, fontWeight: FontWeight.w400),
                        ),
                        Expanded(
                          child: Divider(
                              color: Colors.black54,
                              thickness: .5,
                              indent: 10,
                              endIndent: 10),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 25,
                    ),
                    SizedBox(
                      width: 350,
                      height: 45,
                      child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.white,
                              side: BorderSide(
                                width: 2,
                                color: Colors.deepOrange,
                              ),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10))),
                          child: Text("Login",
                              style: GoogleFonts.poppins(
                                  fontSize: 25,
                                  fontWeight: FontWeight.bold,
                                  textStyle: TextStyle(
                                      color: Colors.deepOrange,
                                      letterSpacing: .5))),
                          onPressed: () {
                            myCubit.GoLogin(context);
                          }),
                    ), //login
                    const SizedBox(height: 35)
                  ]),
                ),
              ));
            }));
  }
}
