import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../home.dart';
import '../homePages/layout/layout_screen.dart';
import '../login/login.dart';
import '../../view model/database/network/network/dio_helper.dart';
import '../../view model/database/network/network/end_points.dart';

part 'signuoState.dart';
class signupCubit extends Cubit<signupState>{
  signupCubit():super(signup_Initial());


  static signupCubit get(context) => BlocProvider.of(context);
  TextEditingController name = TextEditingController();
  TextEditingController emailct = TextEditingController();
  TextEditingController passwordct = TextEditingController();
  TextEditingController passwordct0 = TextEditingController();
  TextEditingController phoneNum = TextEditingController();
  TextEditingController gender = TextEditingController();
  TextEditingController university = TextEditingController();
  TextEditingController grade = TextEditingController();

  void registerUser(BuildContext context){
    var data = {

      "email" : emailct.text,
      "password" : passwordct.text,
      "re_password": passwordct0.text,
      "phone": phoneNum.text,
      "gender": gender.value,
      "uni" : university.value,
      "grade": grade.value

    };
    DioHelper.postData(url: registerEndPoint, data: data).then((value){
      print(value.data);
      print(value.statusCode);
      Navigator.push(context, MaterialPageRoute(builder: (context) => Layout(),));

    }).catchError((onError){
      print(onError);
    });
  }
  void GoLogin(BuildContext context){
    Navigator.push(context, MaterialPageRoute(builder: (context) => login(),));
  }
}