import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:myproject/pages/homePages/lecture/lectures.dart';
import 'homePages/events/evevts.dart';
import 'homePages/finals_midterms/finals.dart';
import '../components/card_component.dart';
import 'homePages/midterms.dart';
import 'homePages/news/news.dart';
import 'homePages/notes/Notes.dart';
import 'homePages/sections/sections.dart';


class home extends StatelessWidget{
  const home({super.key});

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return MaterialApp(
        debugShowCheckedModeBanner: false,
      home:Scaffold(
        body: SafeArea(
          child: Column(
              children: [
                const SizedBox(
                    height: 12
                ),
                Row(
                   mainAxisAlignment: MainAxisAlignment.center,
                   children: [
                       Text("Orange " , style: GoogleFonts.poppins(
                       fontSize: 20,
                       fontWeight: FontWeight.bold,
                       textStyle: const TextStyle(color: Colors.deepOrange, letterSpacing: .5))),
                       Text("Digital Center", style: GoogleFonts.poppins(
                         fontSize: 20,
                         fontWeight: FontWeight.bold
              ))
              ]),
                Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Column(
                children: [
                  SizedBox(height: 10,),
                  TextButton(
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) =>lectures()));
                      },
                      child: CardHome("assets/icons/lecture.svg", "Lectures")),
                  TextButton(
                    onPressed: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) =>midterms()));

                    },
                    child:CardHome("assets/icons/midterm.svg", "Midterms"),),
                  TextButton(
                    onPressed: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) =>events()));
                    },
                  child:CardHome("assets/icons/event.svg", "Events")),
                ],
              ),
              Column(
                children: [
                  SizedBox(height: 10,),
                  TextButton(
                    onPressed: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) =>sections()));
                    },
                    child:CardHome(("assets/icons/sections.svg"), "Sections"),),
                  TextButton(
                    onPressed: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) =>finals()));

                    },
                    child:CardHome("assets/icons/final.svg", "Finals"),),
                  TextButton(
                    child:CardHome("assets/icons/notes.svg", "Notes"),
                    onPressed: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) =>Notes()));
                    },)
                ],
              )
            ],
          ),
              ]),

        ),


      )
    );

  }
  
}