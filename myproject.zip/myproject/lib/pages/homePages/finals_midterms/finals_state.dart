part of 'finals_cubit.dart';

@immutable
abstract class finals_state {}

class finalsInitial extends finals_state {}
class finalsDataStored extends finals_state {}