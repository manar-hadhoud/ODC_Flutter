import 'package:bloc/bloc.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../model/finals_model.dart';
import '../../../view model/database/network/network/dio_helper.dart';
import '../../../view model/database/network/network/end_points.dart';
import '../lecture/constant.dart';

part 'finals_state.dart';

class finals_cubit extends Cubit<finals_state>{
  finals_cubit(): super(finalsInitial());
  static finals_cubit get(context) => BlocProvider.of(context);
  static ExamModel ? examsModel;

  void getDatafinals(){
    DioHelper.getData(url: examsEndPoint,token: token).then((value){
      examsModel = ExamModel.fromJson(value.data);
      print(examsModel!.message.toString());
      emit(finalsDataStored());


    });
  }

}
