import 'package:flutter/material.dart';


class addNotes extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
        home: SafeArea(
        child: Scaffold(
        body: Column(
            children: [
              const SizedBox(height: 30,),
              Row(
                children: [

                  InkWell(
                    onTap: () => Navigator.pop(context),
                    child:const Icon(Icons.arrow_back_ios_new),),
                  const SizedBox(width: 120,),
                  const Text("Add Note", style: TextStyle( fontWeight: FontWeight.w500,
                      fontSize: 30,color: Colors.black, letterSpacing: .5),),
                ],
              ),
              const SizedBox(height: 50,),
              SizedBox(
                  width: 380,
                  height: 60,
                  child: TextFormField(
                    decoration: InputDecoration(
                      labelText: "Title",
                      hintText: "Enter Title",
                      //prefixIcon: Icon(Icons.email_sharp, color: Colors.black54,),
                      hintStyle: const TextStyle(color: Colors.grey),
                      labelStyle: const TextStyle(color: Colors.black87),
                      filled: true,
                      fillColor: Colors.white,
                      enabledBorder: const OutlineInputBorder(
                        borderRadius: BorderRadius.only(topLeft: Radius.circular(16),bottomRight: Radius.circular(16)),
                        borderSide: BorderSide(color: Colors.teal, width: 1),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: const BorderRadius.only(topLeft: Radius.circular(16),bottomRight: Radius.circular(16)),
                        borderSide: BorderSide(color: Colors.pinkAccent.shade100, width: 1),
                      ),
                    ),
                  )
              ),
              const SizedBox(height: 30,),
              SizedBox(
                  width: 380,
                  height: 60,
                  child:TextFormField(
                    initialValue: "2022-09-28 00:36:59.161424",
                    decoration: InputDecoration(
                      labelText: "Date",
                      hintText: "2022-09-28 00:36:59.161424",
                      //prefixIcon: Icon(Icons.email_sharp, color: Colors.black54,),
                      hintStyle: const TextStyle(color: Colors.grey),
                      labelStyle: const TextStyle(color: Colors.black87),
                      filled: true,
                      fillColor: Colors.white,
                      enabledBorder: const OutlineInputBorder(
                        borderRadius: BorderRadius.only(topLeft: Radius.circular(16),bottomRight: Radius.circular(16)),
                        borderSide: BorderSide(color: Colors.teal, width: 1),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.only(topLeft: Radius.circular(16),bottomRight: Radius.circular(16)),
                        borderSide: BorderSide(color: Colors.pinkAccent.shade100, width: 1),
                      ),
                    ),
                  )
              ),
              const SizedBox(height: 30,),
              Container(
                margin: const EdgeInsets.fromLTRB(2, 7, 2, 0),
                width: 380,
                  child:TextFormField(
                    minLines: 6,
                    maxLines: 8,
                    decoration: InputDecoration(
                      labelText: "Note",
                      hintText: "Enter Note",
                      //prefixIcon: Icon(Icons.email_sharp, color: Colors.black54,),
                      hintStyle: const TextStyle(color: Colors.grey),
                      labelStyle: const TextStyle(color: Colors.black87),
                      filled: true,
                      isDense: true,
                      fillColor: Colors.white,
                        //contentPadding: EdgeInsets.symmetric(vertical: 60.0,horizontal: 10.0),
                      enabledBorder: const OutlineInputBorder(
                        borderRadius: BorderRadius.only(topLeft: Radius.circular(16),bottomRight: Radius.circular(16)),
                        borderSide: BorderSide(color: Colors.teal, width: 1),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: const BorderRadius.only(topLeft: Radius.circular(16),bottomRight: Radius.circular(16)),
                        borderSide: BorderSide(color: Colors.pinkAccent.shade100, width: 1),
                      ),
                    ),
                  )
              ),
              const SizedBox(height: 20,),
              Center(
                  child: ElevatedButton.icon(
                      icon: const Icon(
                        Icons.add,
                        color: Colors.black,
                        size: 20.0,
                      ),
                      label: const Text("Add", style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w400,
                          color: Colors.black)),
                      onPressed: () {

                      },
                      style: ElevatedButton.styleFrom(
                        primary: Colors.blueGrey,
                        shape: RoundedRectangleBorder(
                          borderRadius: new BorderRadius.circular(5),
                        ),
                      )
                  )
              ),

            ]
        ),
      ),
        )
    );
  }

}