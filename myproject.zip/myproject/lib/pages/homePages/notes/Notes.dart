
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'addNotes.dart';

class Notes extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        home: SafeArea(
        child: Scaffold(
        body: Column(
          children: [
            const SizedBox(height: 30,),
            Row(
              children:  [
                InkWell(
                  onTap: () => Navigator.pop(context),
                  child:const Icon(Icons.arrow_back_ios_new),),
                  const SizedBox(width: 120,),
                  const Text("Notes", style: TextStyle( fontWeight: FontWeight.w500,
                    fontSize: 30,color: Colors.black, letterSpacing: .5),),
              ],
            ),
            const SizedBox(height: 300,),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("There's No Data To Show", style: GoogleFonts.poppins(
                    fontSize: 25,
                    fontWeight: FontWeight.w400,
                    textStyle: const TextStyle(color: Colors.black, letterSpacing: .5),
                  ))
                ],
              ),
          ],
        ),
        floatingActionButton: FloatingActionButton(
          backgroundColor: Colors.black12,
          foregroundColor: Colors.black,
          onPressed: () => {
          Navigator.push(context, MaterialPageRoute(builder: (context) =>addNotes()))
          },
          child: Icon(Icons.add)
        ),

    )
        )
    );
  }
}





