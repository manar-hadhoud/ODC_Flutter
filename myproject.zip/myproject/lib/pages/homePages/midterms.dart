import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';

import 'finals_midterms/finals_cubit.dart';
import '../../components/lectureComponent.dart';

class midterms extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
        create: (context) => finals_cubit()..getDatafinals(),
        child: BlocConsumer<finals_cubit, finals_state>(
            listener: (context, state) {},
            builder: (context, state) {
              finals_cubit mycubit = finals_cubit.get(context);
              return MaterialApp(
                  debugShowCheckedModeBanner: false,
                  home: Scaffold(
                      appBar: AppBar(
                          backgroundColor: Colors.white,
                          leading: IconButton(
                            icon: const Icon(
                              Icons.arrow_back_ios,
                              color: Colors.deepOrange,
                            ),
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                          ),
                          centerTitle: true,
                          title: Text(
                            "Midterms",
                            style: GoogleFonts.poppins(
                              fontSize: 26,
                              fontWeight: FontWeight.bold,
                              textStyle: const TextStyle(
                                color: Colors.black,
                              ),
                            ),
                          ),
                          actions: [
                            PopupMenuButton(
                                icon: const Icon(Icons.filter_alt, color: Colors.deepOrange,),
                                itemBuilder: (context) =>
                                [
                                  PopupMenuItem(
                                    value: 1,
                                    child: Text("All Midterms", style: GoogleFonts.poppins(
                                      fontSize: 15,
                                      fontWeight: FontWeight.w400,
                                      textStyle: const TextStyle(
                                          color: Colors.black, letterSpacing: .5),
                                    )),
                                  ),
                                  PopupMenuItem(
                                    value: 2,
                                    child: Text("Finished Midterms", style: GoogleFonts.poppins(
                                      fontSize: 15,
                                      fontWeight: FontWeight.w400,
                                      textStyle: const TextStyle(
                                          color: Colors.black, letterSpacing: .5),
                                    )),
                                  ),
                                  PopupMenuItem(
                                    value: 2,
                                    child: Text(
                                        "Remaining Midterms", style: GoogleFonts.poppins(
                                      fontSize: 15,
                                      fontWeight: FontWeight.w400,
                                      textStyle: const TextStyle(
                                          color: Colors.black, letterSpacing: .5),
                                    )),
                                  )
                                ]
                            ),
                          ]),
                      body: Container(child: finals_cubit.examsModel == null ? const Center(
                        child: CircularProgressIndicator(
                            color: Colors.deepOrangeAccent),) : ListView.builder(
                          shrinkWrap: true,
                          itemCount: 3,
                          itemBuilder: (BuildContext context, int index) {
                            return homeCard(finals_cubit.examsModel!.data![index].examSubject
                                .toString(),
                                finals_cubit.examsModel!.data![index].examDate
                                    .toString(),
                                finals_cubit.examsModel!.data![index].examStartTime
                                    .toString(),
                                finals_cubit.examsModel!.data![index].examEndTime
                                    .toString());
                          }),
                      )
                  )
              );

            }));
  }
}