
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_nav_bar/google_nav_bar.dart';
import 'layout_cubit.dart';

class Layout extends StatelessWidget {
  const Layout({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => LayoutCubit(),
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: ThemeData(primarySwatch: Colors.deepOrange),
        home: BlocConsumer<LayoutCubit, LayoutState>(
          listener: (context, state) {
            // TODO: implement listener
          },
          builder: (context, state) {
            LayoutCubit myCubit = LayoutCubit.get(context);
            return Scaffold(
              body: myCubit.pages[myCubit.currentIndex],
              bottomNavigationBar: GNav(
                  haptic: true,

                  selectedIndex: myCubit.currentIndex,
                  backgroundColor: Colors.white,
                  hoverColor: Colors.white10,

                  // haptic feedback
                  tabBorderRadius: 15,
                  tabActiveBorder: Border.all(color: Colors.white10, width: 0),
                  // tab button border
                  tabBorder: Border.all(color: Colors.white10, width: 0),
                  // tab button border
                  tabShadow: [
                    BoxShadow(
                        color: Colors.grey.withOpacity(0.5), blurRadius: 8)
                  ],
                  // tab button shadow
                  curve: Curves.easeOutExpo,
                  // tab animation curves
                  duration: Duration(milliseconds: 700),
                  // tab animation duration
                  gap: 8,
                  // the tab button gap between icon and text
                  color: Colors.black87,
                  // unselected icon color
                  activeColor: Colors.deepOrangeAccent,
                  // selected icon and text color
                  iconSize: 24,
                  // tab button icon size
                  tabBackgroundColor: Colors.white10.withOpacity(0.1),
                  // selected tab background color
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  // navigation bar padding
                  onTabChange: (value) {
                    myCubit.changeCurrent(value);
                  },
                  tabs: [
                    GButton(
                      icon: Icons.home,
                      text: 'Home',
                      backgroundColor: Colors.grey[200],
                      border: Border.all(color: Colors.white10),
                      borderRadius: BorderRadius.circular(30),
                      padding: const EdgeInsets.all(12),
                    ),
                    GButton(
                      icon: Icons.newspaper,
                      text: 'Likes',
                      backgroundColor: Colors.grey[200],
                      border: Border.all(color: Colors.white10),
                      borderRadius: BorderRadius.circular(30),
                      padding: const EdgeInsets.all(12),
                    ),
                    GButton(
                      icon: Icons.settings,
                      text: 'Search',
                      backgroundColor: Colors.grey[200],
                      border: Border.all(color: Colors.white10),
                      borderRadius: BorderRadius.circular(30),
                      padding: const EdgeInsets.all(12),

                    ),
                  ]),
              );
          },
        ),
      ),
    );
  }
}


