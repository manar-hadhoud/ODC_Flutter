import 'package:bloc/bloc.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:meta/meta.dart';

import '../../home.dart';
import '../news/news.dart';
import '../../settings.dart';

part 'layoutState.dart';

class LayoutCubit extends Cubit<LayoutState> {
  LayoutCubit() : super(LayoutInitial());
  static LayoutCubit get(context) => BlocProvider.of(context);

  List<Widget> pages = [home() , news(), settings()];
  int currentIndex = 0;

  void changeCurrent(int newIndex){
    currentIndex = newIndex;
    emit(IndexChanged());
  }



}
