

import 'package:bloc/bloc.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:myproject/model/lecture_model.dart';
import 'package:myproject/view%20model/database/network/network/dio_helper.dart';
import 'package:myproject/view%20model/database/network/network/end_points.dart';

import 'constant.dart';

part 'lecture_state.dart';

class Lecture_Cubit extends Cubit<Lecture_state>{
  Lecture_Cubit(): super(lectureInitial());
  static Lecture_Cubit get(context) => BlocProvider.of(context);
  static LectureModel ? lectureModel;

  void getDataLectures(){
    DioHelper.getData(url: lectureEndPoint,token: token).then((value){
      lectureModel = LectureModel.fromJson(value.data);
      print(lectureModel!.code);
      emit(lectureDataStored());


    });
  }

}

