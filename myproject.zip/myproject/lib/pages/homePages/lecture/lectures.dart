
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../components/lectureComponent.dart';
import 'lecture_Cubit.dart';


class lectures extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
        create: (context) =>
        Lecture_Cubit()
          ..getDataLectures(),
        child: BlocConsumer<Lecture_Cubit, Lecture_state>(
            listener: (context, state) {},
            builder: (context, state) {
              debugShowCheckedModeBanner: false;
              Lecture_Cubit mycubit = Lecture_Cubit.get(context);
              return MaterialApp(
                  debugShowCheckedModeBanner: false,
                  home: Scaffold(
                      appBar: AppBar(
                          backgroundColor: Colors.white,
                          leading: IconButton(icon: const Icon(
                            Icons.arrow_back_ios, color: Colors.deepOrange,),
                            onPressed: () {
                              Navigator.of(context).pop();
                            },),
                          centerTitle: true,
                          title: Text("Lectures", style: GoogleFonts.poppins(
                            fontSize: 26,
                            fontWeight: FontWeight.bold,
                            textStyle: const TextStyle(color: Colors.black,),

                          ),
                          ),
                          actions: [
                            PopupMenuButton(
                                icon: const Icon(Icons.filter_alt, color: Colors.deepOrange,),
                                itemBuilder:(context) => [
                                  PopupMenuItem(
                                    value: 1,
                                    child: Text("All Lectures", style: GoogleFonts.poppins(
                                      fontSize: 15,
                                      fontWeight: FontWeight.w400,
                                      textStyle: TextStyle(color: Colors.black, letterSpacing: .5),
                                    )),
                                  ),
                                  PopupMenuItem(
                                    value: 2,
                                    child: Text("Finished Lectures", style: GoogleFonts.poppins(
                                      fontSize: 15,
                                      fontWeight: FontWeight.w400,
                                      textStyle: const TextStyle(color: Colors.black, letterSpacing: .5),
                                    )),
                                  ),
                                  PopupMenuItem(
                                    value: 2,
                                    child: Text("Remaining Lectures", style: GoogleFonts.poppins(
                                      fontSize: 15,
                                      fontWeight: FontWeight.w400,
                                      textStyle: const TextStyle(color: Colors.black, letterSpacing: .5),
                                    )),
                                  )
                                ]
                            )
                          ]

                      ),
                      body: Container(
                          child: Lecture_Cubit.lectureModel == null ? const Center(
                            child: CircularProgressIndicator(
                                color: Colors.deepOrangeAccent),) : ListView
                              .builder(
                            itemCount: Lecture_Cubit.lectureModel!.data!.length,
                            shrinkWrap: true,
                            itemBuilder: ((BuildContext context, int index) {
                              return homeCard(
                                  Lecture_Cubit.lectureModel!.data![index]
                                      .lectureSubject.toString(),
                                  Lecture_Cubit.lectureModel!.data![index]
                                      .lectureDate.toString(),
                                  Lecture_Cubit.lectureModel!.data![index]
                                      .lectureStartTime.toString(),
                                  Lecture_Cubit.lectureModel!.data![index]
                                      .lectureEndTime.toString());
                            }),

                          )
                      )
                  )
              );
            }
        )
    );
  }
}
