

//import 'package:flutter/cupertino.dart';

part of 'lecture_Cubit.dart';
@immutable
abstract class Lecture_state {}

class lectureInitial extends Lecture_state {}
class lectureDataStored extends Lecture_state {}
