import 'package:flutter/material.dart';


class ODCshow extends StatelessWidget {
  //const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      home: Scaffold(
        body: SingleChildScrollView(
          child: SafeArea(
            child:Column(
              children: [
                InkWell(
                   splashColor: Colors.black12,

                   child: Ink.image(image: AssetImage("assets/images/logo.png"),
                   height: 300
                    ,width:370,
                       child:Column(
                           children: [
                           SizedBox(height: 15),
                       Row(
                         children: [SizedBox(width: 10),
                           CircleAvatar(
                             child: IconButton(
                               icon: Icon(Icons.arrow_back_ios_new)
                             ,color: Colors.deepOrange, onPressed: () {
                             Navigator.of(context).pop();
                           },),
                               backgroundColor:Colors.white,maxRadius: 30,)
                         ],
                       )
                   ])
                )
                )

                ,const SizedBox(
                  height: 30,
                ),
                const SizedBox(
                  height: 30,
                ),
                Row(crossAxisAlignment: CrossAxisAlignment.start, children: const [
                  SizedBox(width: 20),Text(
                    "ODCs",
                    style: TextStyle(
                        fontSize: 30,
                        color: Colors.black,
                        fontWeight: FontWeight.bold),
                  ),
                  //Text("s",style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 22),),
                  //Text("2022-07-06",style: TextStyle(color: Colors.deepOrange,fontWeight: FontWeight.bold,fontSize: 15),),
                ]),
                const SizedBox(
                  height: 10,
                ),
                Row(crossAxisAlignment: CrossAxisAlignment.start, children: const [
                  SizedBox(width: 20),
                  Text("2022-07-06",style: TextStyle(color: Colors.orange,fontWeight: FontWeight.w300,fontSize: 15),),
                ]),
                const SizedBox(
                  height: 20,
                ),
                Row(crossAxisAlignment: CrossAxisAlignment.center, children: const [
                  const SizedBox(
                    width: 70,
                  ),Text(
                    "ODC Support All Universties",
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.black54,
                    ),
                  ),
                ]),
              ],
            ),
          ),
        ),
      ),
    );
  }
}