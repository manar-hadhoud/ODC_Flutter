import 'package:bloc/bloc.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../model/section_model.dart';
import '../../../view model/database/network/network/dio_helper.dart';
import '../../../view model/database/network/network/end_points.dart';
import '../lecture/constant.dart';

part 'section_state.dart';

class section_cubit extends Cubit<section_state>{
  section_cubit(): super(sectionInitial());
  static section_cubit get(context) => BlocProvider.of(context);
  static SectionModel ? sectionModel;

  void getDataLectures(){
    DioHelper.getData(url: sectionEndPoint,token: token).then((value){
      sectionModel = SectionModel.fromJson(value.data);
      print(sectionModel!.message.toString());
      emit(sectionDataStored());


    });
  }

}
