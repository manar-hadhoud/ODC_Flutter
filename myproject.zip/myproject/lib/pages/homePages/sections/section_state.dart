part of 'section_cubit.dart';

@immutable
abstract class section_state {}

class sectionInitial extends section_state {}
class sectionDataStored extends section_state {}