import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:syncfusion_flutter_calendar/calendar.dart';


class events extends StatelessWidget {

@override
Widget build(BuildContext context) {

  return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
      appBar: AppBar(
      backgroundColor: Colors.white,
      leading: IconButton(icon: const Icon(
      Icons.arrow_back_ios, color: Colors.deepOrange,), onPressed: () { Navigator.of(context).pop(); },),
      centerTitle: true,
      title: Text("Midterms", style: GoogleFonts.poppins(
      fontSize: 26,
      fontWeight: FontWeight.bold,
      textStyle: const TextStyle(color: Colors.black,),

  ),
  )
  ),
        body: SfCalendar(
          view: CalendarView.month,
          initialSelectedDate: DateTime.now(),
            monthViewSettings: const MonthViewSettings(
                appointmentDisplayMode: MonthAppointmentDisplayMode.appointment)
        )
  )
  );
}
}