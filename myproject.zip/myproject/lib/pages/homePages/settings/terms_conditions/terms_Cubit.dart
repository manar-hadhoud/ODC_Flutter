import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:myproject/pages/homePages/settings/terms_conditions/terms_State.dart';

import '../../../../model/terms_Model.dart';
import '../../../../view model/database/network/network/dio_helper.dart';
import '../../../../view model/database/network/network/end_points.dart';
import '../../lecture/constant.dart';

class TermsCubit extends Cubit<TermsStates>
{
  TermsCubit() : super(TermsIntialState());

  static TermsCubit get(BuildContext context)=> BlocProvider.of(context);
  TermModel? termModel;
  void getTerms()
  {
    DioHelper.getData(url: termsEndPoint,token: token).then((value) {
      termModel=TermModel.fromJson(value.data);
      print(value.statusCode);
      emit(TermsStoredData());
    });
  }

}