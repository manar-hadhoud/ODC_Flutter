import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';


class ourPartenrs extends StatelessWidget {
  const ourPartenrs({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Scaffold(
          appBar: AppBar(

            leading: new IconButton(icon:Icon(
              Icons.arrow_back_ios, color: Colors.deepOrange,), onPressed: () {
              Navigator.of(context).pop();
            },),
            centerTitle: true,
            title: Text("Our Partners", style: GoogleFonts.poppins(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              textStyle: const TextStyle(color: Colors.black,),

            ),
            ),
            backgroundColor: Colors.white,
          ),
          body: Column(
            children: [
              SizedBox(height: 20),
              Center(
                  child: Container(
                      width: 300,
                      height: 250,
                      decoration: BoxDecoration(
                          gradient: const LinearGradient(
                              begin: Alignment.bottomCenter,
                              end: Alignment.topCenter,
                              colors: [
                                Colors.grey,
                                Colors.white,
                                Colors.grey,
                              ]),
                          border: Border.all(
                            color: Colors.white12,
                          ),
                          borderRadius: BorderRadius.circular(16)
                      ),

                      child: Column(
                        children: [
                          SizedBox(height: 10),
                          Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: const [
                                SizedBox(width: 10),
                                Text(
                                  "ODC",
                                  style: TextStyle(
                                    fontSize: 22,
                                    color: Colors.white,
                                  ),
                                ),
                              ]),
                          const SizedBox(
                            height: 10,
                          ),
                          Image.asset('assets/images/logo.png'),
                        ],
                        )
                      //child:
                    ),
              )]

              )

            ,
          )
        );

  }
}
