
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';


class support extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(

          leading:IconButton(icon:const Icon(Icons.arrow_back_ios,
        color:Colors.deepOrange,), onPressed: () {
            Navigator.of(context).pop();
          },),
          centerTitle: true,
          title: Text("Support" ,style: GoogleFonts.poppins(
          fontSize: 26,
          fontWeight: FontWeight.bold,
          textStyle: const TextStyle(color: Colors.black,),

          ),
        ),
          backgroundColor: Colors.white,
      ),


        body: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
            const SizedBox(
            height: 30),
              Container(
                width: 350,
                  margin: EdgeInsets.fromLTRB(0, 3, 0, 0),

              child:TextField(
                   obscureText: true,
                    decoration: InputDecoration(
                        labelText: "Name",
                        hintStyle: TextStyle(color: Colors.black38),
                        labelStyle: TextStyle(color: Colors.deepOrange),
                        focusedBorder: const OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(5)),
                            borderSide: BorderSide(
                              color: Colors.deepOrangeAccent,
                            )),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10))
                        , hintText: 'Name',
                        prefixIcon: Icon(Icons.person),
                        isDense: true,
                        fillColor: Colors.black12,
                        filled: true
                    ),

                  )
          ),
              const SizedBox(
                height: 20,
              ),
              Container(
                  margin: EdgeInsets.fromLTRB(0, 5, 0, 0),
                  width: 350,
                  child: TextField(
                    decoration: InputDecoration(
                        labelText: "E-Mail",
                        hintStyle: TextStyle(color: Colors.black38),
                        labelStyle: TextStyle(color: Colors.deepOrange),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                        hintText: 'E-Mail', prefixIcon: Icon(Icons.email_outlined,color: Colors.black38,)
                        ,fillColor: Colors.black12,
                        filled: true,
                        focusedBorder: const OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(5)),
                            borderSide: BorderSide(
                              color: Colors.deepOrangeAccent,
                            ))
                    ),
                  )
              ),
              const SizedBox(
                  height: 10),
               Container(
                   margin: EdgeInsets.fromLTRB(0, 10, 0, 0),
                  width: 400,
                  //margin: EdgeInsets.all(10),

                  child: TextField(
                    minLines: 6,
                    maxLines: 8,
                    decoration: InputDecoration(

                        focusedBorder: const OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(5)),
                            borderSide: BorderSide(
                              color: Colors.deepOrangeAccent,
                            )),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                        hintText: "What's making you unhappy?",
                        isDense: true,

                        fillColor: Colors.black12,
                       filled: true

                    ),
                    //style: Size.square(30,30),
                  )
              ),

              const SizedBox(
                height: 20,
              ),
              SizedBox(
                width: 350,
                height: 45,
                child: ElevatedButton(
                    style: ElevatedButton.styleFrom(primary: Colors.deepOrange),
                    child: Text("Submit", style: GoogleFonts.poppins(
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                        textStyle: const TextStyle(color: Colors.white, letterSpacing: .5)
                    )),
                    onPressed:(){}
                ),
              ),


            ],
          ),
        ),
      ),
    );
  }
}