import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';

import 'loginCubit.dart';
import 'login_State.dart';



class login extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
        create: (context) => loginCubit(),
        child: BlocConsumer<loginCubit, login_State>(
            listener: (context, state) {
            }
            , builder: (context, state) {
          loginCubit myCubit = loginCubit.get(context);
          return MaterialApp(
            debugShowCheckedModeBanner: false,
            home: Scaffold(
              body: SingleChildScrollView(
                child: Column(
                  children: [
                    SizedBox(
                      height: 70,
                    ),
                    Center(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(height: 80,),
                          Text("Orange ", style: GoogleFonts.poppins(
                              fontSize: 25,
                              fontWeight: FontWeight.bold,
                              textStyle: TextStyle(
                                  color: Colors.deepOrange, letterSpacing: .5)
                          )),
                          Text("Digital Center", style: GoogleFonts.poppins(
                              fontSize: 25,
                              fontWeight: FontWeight.bold
                          ))
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 50,
                    ),
                    ListTile(
                      title: Text("Login", style: GoogleFonts.poppins(
                          fontSize: 28,
                          fontWeight: FontWeight.w500
                      )),
                    ),
                    const SizedBox(
                      height: 10,
                    ),

                    SizedBox(
                        width: 350,
                        height: 45,
                        child: TextFormField(
                          controller: myCubit.emailct,
                          decoration: InputDecoration(
                              labelText: 'E-Mail',
                              hintText: "E-mail" ,
                            labelStyle: TextStyle(color: Colors.deepOrange) ,
                            hintStyle: TextStyle(color: Colors.black38),
                              focusedBorder: const OutlineInputBorder(
                                  borderRadius: BorderRadius.all(Radius.circular(5)),
                                  borderSide: BorderSide(
                                    color: Colors.deepOrangeAccent,
                                  )),
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(13))
                              ,
                         )
                    )
                    ), // email
                    SizedBox(
                      height: 20,
                    ),
                    SizedBox(
                        width: 350,
                        height: 45,
                        child: TextFormField(
                          controller: myCubit.passwordct,
                          decoration: InputDecoration(
                              labelText: 'password',
                              hintText: "password" ,
                              labelStyle: TextStyle(color: Colors.deepOrange) ,
                              hintStyle: TextStyle(color: Colors.black38),
                              focusedBorder: const OutlineInputBorder(
                                  borderRadius: BorderRadius.all(Radius.circular(5)),
                                  borderSide: BorderSide(
                                    color: Colors.deepOrangeAccent,
                                  )),
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(15)),
                              suffixIcon: Icon(Icons.visibility_off,color: Colors.deepOrange)),
                        )
                    ), //pass
                    const SizedBox(
                      height: 0,
                    ),
                    ListTile(
                      leading: Text(
                          "Forgot Password?", style: GoogleFonts.poppins(
                          textStyle: TextStyle(color: Colors.deepOrange,
                              letterSpacing: .5,
                              decoration: TextDecoration.underline)
                      )),
                    ),
                    SizedBox(
                      height: 50,
                    ),
                    SizedBox(
                      width: 350,
                      height: 45,
                      child: ElevatedButton(
                          style: ElevatedButton.styleFrom(primary: Colors
                              .deepOrange,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10))),
                          child: Text("Login", style: GoogleFonts.poppins(
                              fontSize: 25,
                              fontWeight: FontWeight.bold,
                              textStyle: TextStyle(
                                  color: Colors.white, letterSpacing: .5)
                          )),
                          onPressed: () {
                              myCubit.loginUser(context);
                          }
                      ), // login
                    ), // login
                    SizedBox(
                      height: 30,
                    ),
                    Row(
                      children: const [
                        Expanded(
                          child: Divider(
                              color: Colors.black54,
                              thickness: .5,
                              indent: 10,
                              endIndent: 10
                          ),
                        ),
                        Text("OR", style: TextStyle(
                            fontSize: 20, fontWeight: FontWeight.w400),),
                        Expanded(
                          child: Divider(
                              color: Colors.black54,
                              thickness: .5,
                              indent: 10,
                              endIndent: 10
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 30,
                    ),
                    SizedBox(
                      width: 350,
                      height: 45,
                      child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.white,
                              side: const BorderSide(
                                width: 2, color: Colors.deepOrange,)
                              , shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10))),
                          child: Text("Sign Up", style: GoogleFonts.poppins(
                              fontSize: 25,
                              fontWeight: FontWeight.bold,
                              textStyle: const TextStyle(
                                  color: Colors.deepOrange, letterSpacing: .5)
                          )),
                          onPressed: () {
                            myCubit.GoSignup(context);

                          }
                      ),
                    ), // signup
                  ],
                ),
              ),
            ),
          );
        }
        )

    );
  }
}