//import 'dart:js';

import 'package:bloc/bloc.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:myproject/pages/home.dart';
import 'package:myproject/pages/signup/signUp.dart';
import '../../view model/database/network/network/dio_helper.dart';
import '../../view model/database/network/network/end_points.dart';

import '../homePages/layout/layout_screen.dart';
import 'login_State.dart';

class loginCubit extends Cubit<login_State>{
  loginCubit():super(login_Initial());

  //BuildContext get context => context;

  static loginCubit get(context) => BlocProvider.of(context);


  TextEditingController emailct = TextEditingController();
  TextEditingController passwordct = TextEditingController();
  //Navigator.push(context, MaterialPageRoute(builder: (context) => NevBarLayout(),));

  void loginUser(BuildContext context){
    var data = {
      "email" : emailct.text,
      "password" : passwordct.text
    };
    DioHelper.postData(url: loginEndPoint, data: data).then((value){
      print(value.data);
      print(value.statusCode);
      Navigator.push(context, MaterialPageRoute(builder: (context) => Layout(),));

    }).catchError((onError){
      print(onError);
    });
  }
  void GoSignup(BuildContext context){
    Navigator.push(context, MaterialPageRoute(builder: (context) => signUp(),));
  }


}