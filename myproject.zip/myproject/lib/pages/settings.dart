import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:myproject/pages/homePages/settings/FAQ.dart';
import 'package:myproject/pages/homePages/settings/ourPartenrs.dart';
import 'package:myproject/pages/homePages/settings/support.dart';

import 'homePages/settings/terms_conditions/terms_conditions.dart';
import 'login/login.dart';

enum DialogsAction {yes,cancel}



class settings extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
      home:Scaffold(
        body: Column(
          children : [
            const SizedBox(height: 80),
            const Center(
              child: Text("Settings", style: TextStyle(color: Colors.black,
                  fontSize: 25,
                  fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 20),
            InkWell(
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context) =>FAQ()));
                }
                ,child:ListTile(
              title: Text("FAQ"),
              trailing: Icon(Icons.arrow_forward_ios),
            )),
            const Divider(
              color: Colors.black54,
              thickness: .7,
              indent: 10,
              endIndent: 10,
            ),
        InkWell(
          onTap: (){
            Navigator.push(context, MaterialPageRoute(builder: (context) =>TermsScreen()));
          }
          ,child:ListTile(
              title: Text("Terms & Conditions"),
              trailing: Icon(Icons.arrow_forward_ios),
            )),
            const Divider(
              color: Colors.black54,
              thickness: .7,
              indent: 10,
              endIndent: 10,
            ),
        InkWell(
          onTap: (){
            Navigator.push(context, MaterialPageRoute(builder: (context) =>const ourPartenrs()));
          }
          ,child:const ListTile(
              title: Text("Our Partners"),
              trailing: Icon(Icons.arrow_forward_ios),
            )),
            const Divider(
              color: Colors.black54,
              thickness: .7,
              indent: 10,
              endIndent: 10,
            ),
        InkWell(
          onTap: (){
            Navigator.push(context, MaterialPageRoute(builder: (context) =>support()));
          }
          ,child:const ListTile(
              title: Text("Support"),
              trailing: Icon(Icons.arrow_forward_ios ),
            )),
            const Divider(
              color: Colors.black54,
              thickness: .7,
              indent: 10,
              endIndent: 10,
            ),
            TextButton(
                child:const ListTile(
                  title: Text("Log out"),
                  trailing: Icon(Icons.arrow_forward_ios),
                ),
                onPressed: () {
                  showDialog(
                      context: context,
                      builder: (context) => AlertDialog(
                        title: Text("Log out"),
                        content: Text("Are you sure?"),
                        actions: [
                          SizedBox(width: 5),
                          Container(
                               height: 35,
                              width: 115
                              ,child:ElevatedButton(
                             style: ElevatedButton.styleFrom(
                                    side: BorderSide(width: 2.0, color: Colors.deepOrange),
                                    textStyle: const TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
                                    primary: Colors.white,
                                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))
                                   ),
                              onPressed: () => Navigator.of(context).pop()
                              , child: Text("Cancel",
                               style: TextStyle(color:Colors.deepOrange))

                          )),
                          SizedBox(width: 2),

                      Container(
                        height: 35,
                        width: 115
                        ,child:ElevatedButton(
                               style: ElevatedButton.styleFrom(
                               textStyle: const TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
                                 primary: Colors.deepOrange,
                                 shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))
                               ),
                              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (context) => login(),))
                              , child: Text("sure",
                              style: TextStyle(color:Colors.white))

                          )),
                          SizedBox(width: 5)
                        ],

                      ));
                }
            )
            ,
          ],
        ),

      )
    );
  }

}