import 'dart:async';
import 'package:flutter/material.dart';
import 'package:myproject/pages/homePages/settings/ourPartenrs.dart';
import 'package:myproject/pages/login/login.dart';
import 'package:myproject/pages/signup/signUp.dart';
import 'package:myproject/view%20model/database/network/network/dio_helper.dart';
import 'package:percent_indicator/percent_indicator.dart';

void main() async {

  await DioHelper.init();
  runApp(Myapp());
}

class Myapp extends StatelessWidget {
  const Myapp({Key? key}): super(key: key);


  @override
  Widget build(BuildContext context) {
     return   MaterialApp(
         debugShowCheckedModeBanner: false,
         home: splash()
     );

  }
}

class splash extends StatefulWidget {
  const splash({Key? key}): super(key: key);


  @override
  State<splash> createState() => SplashScreen();
}

class SplashScreen extends State<splash> {

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    Timer(
        Duration(seconds: 4),
            () =>
            Navigator.of(context).pushReplacement(MaterialPageRoute(
                builder: (BuildContext context) => login())));

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: SizedBox(
          width: double.infinity,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image(
                  image: AssetImage("assets/images/logo.png")
                  ,width: 300),
              SizedBox(height: 5),
              Row(

                children:[
                  SizedBox(width: 15),
                  LinearPercentIndicator(
                      width: 360,
                     lineHeight: 7,
                      percent: 1,
                      linearStrokeCap: LinearStrokeCap.round,
                      progressColor: Colors.deepOrangeAccent,
                      backgroundColor: Colors.blueGrey,
                      animation: true,
                       animationDuration: 3105,

                ),

              ])

            ],
          ),
        ) ,

        /*theme: ThemeData(
          primarySwatch: Colors.orange,
        ),

        home: login()*/
      ),
    );
  }


}











