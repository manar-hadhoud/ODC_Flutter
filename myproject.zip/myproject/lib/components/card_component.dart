import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';

Widget CardHome(String c, String textdata){
  return Center(
      child:
      Container(
        width: 160,
        height: 110,
        child: Card(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          shadowColor: Colors.black,
          elevation: 20,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircleAvatar(backgroundColor: Colors.black12,
                maxRadius: 24, child: SvgPicture.asset(c,color: Colors.deepOrange)),
              const SizedBox(height: 10),
              Text( textdata,
                  style: GoogleFonts.poppins(
                      color: Colors.deepOrange,
                      fontSize: 17, fontWeight: FontWeight.w600)
              )
            ],
          ),
        ),
      )
  );

}