import 'package:flutter/material.dart';

Widget sign_Form(String txt, TextEditingController controller) {
  return SizedBox(
      width: 350,
      height: 45,
      child: TextField(
        obscureText: false,
        controller: controller,
        decoration: InputDecoration(
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(13)),
            focusedBorder: const OutlineInputBorder(
                borderRadius: BorderRadius.all(Radius.circular(5)),
                borderSide: BorderSide(
                  color: Colors.deepOrangeAccent,
                )),
            labelText: txt,
            hintText: txt
        )
      )
  );
}