//import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

Widget homeCard(String label,String day,String stime,String etime){
  return Container(
    height: 110,
    width: 350,
    child:Card(
      elevation: 8,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15.0),
      ),

      child: Column(
        children: [
          SizedBox(height: 13),
          Row(
            children: [
              SizedBox(width: 10),Text(label,style: TextStyle(fontSize: 18,
                  fontWeight: FontWeight.w500)),
              SizedBox(width: 200),
              //SvgPicture.asset("assets/icons/time.svg")
              Icon(Icons.timer , size: 20),
              Text("2hrs",style: TextStyle(fontSize: 15))
            ],
          ),
          SizedBox(height: 20),
          Row(
            children: [SizedBox(width: 10),
              Column(
                children: [
                  Text("Lecture Day",style: TextStyle(fontSize: 10,
                      fontWeight: FontWeight.w500,color: Colors.black26)),
                  SizedBox(height: 3,),
                  Row(children: [SizedBox(width: 5),Icon(Icons.calendar_month_outlined,size: 15),
                    SizedBox(width: 3),Text(day,style: TextStyle(fontSize: 10,
                        fontWeight: FontWeight.w300,color: Colors.black))],),

                ],
              )
              ,SizedBox(width: 60),
              Column(
                children: [
                  Text("Lecture Day",style: TextStyle(fontSize: 10,
                      fontWeight: FontWeight.w500,color: Colors.black26)),
                  SizedBox(height: 3,),
                  Row(children: [SizedBox(width: 5),Icon(Icons.watch_later,size: 15,color: Colors.greenAccent),
                    SizedBox(width: 3),Text(stime,style: TextStyle(fontSize: 10,
                        fontWeight: FontWeight.w300,color: Colors.black))],),

                ],
              )
              ,SizedBox(width: 60),
              Column(
                children: [
                  Text("Lecture Day",style: TextStyle(fontSize: 10,
                      fontWeight: FontWeight.w500,color: Colors.black26)),
                  SizedBox(height: 3,),
                  Row(children: [SizedBox(width: 5),Icon(Icons.watch_later,size: 15,color: Colors.redAccent),
                    SizedBox(width: 3),Text(etime,style: TextStyle(fontSize: 10,
                        fontWeight: FontWeight.w300,color: Colors.black))],),

                ],
              )
            ],
          )
        ],
      ) ,

    ),
  );

}